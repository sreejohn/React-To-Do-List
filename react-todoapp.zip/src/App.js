import React, { Component } from "react";
import logo from './logo.svg';
import './App.css';
import PropTypes from 'prop-types';
import $ from 'jquery';
import { toIdentifier } from "@babel/types";
var itemId = 4;
localStorage.removeItem("completeitems");
var INIT_ITEMS = [
	{
		name: 'Todo item 1',
		color: '',
		checked: false,
		edit: false,
		id: 1
	},
	{
		name: 'Todo item 2',
		color: 'pink',
		checked: false,
		edit: false,
		id: 2
	},
	{
		name: 'Todo item 3',
		color: 'purple',
		checked: false,
		edit: false,
		id: 3
	}
];

var COLORS = [
	{
		name: 'white',
		checked: true,
		id: 1,
	},
	{
		name: 'pink',
		checked: false,
		id: 2,
	},
	{
		name: 'purple',
		checked: false,
		id: 3,
	},
	{
		name: 'blue',
		checked: false,
		id: 4,
	},
	{
		name: 'green',
		checked: false,
		id: 5,
	},
	{
		name: 'yellow',
		checked: false,
		id: 6,
	}
];
class App extends Component {
	constructor(props) {
		super(props)
		this.state = {
			editstatus: 'false', savestatus: 'false',
			items: [

			], completeitems: [

			],
			countChecked: false,
			checkedNum: 1,
		}

		this.onEditCheck = this.onEditCheck.bind(this);
		this.onMultiDelete = this.onMultiDelete.bind(this);
		this.onCheckedChecker = this.onCheckedChecker.bind(this);
		this.onItemDelete = this.onItemDelete.bind(this);
		this.onItemEdit = this.onItemEdit.bind(this);
		this.onItemAdd = this.onItemAdd.bind(this);
		this.clickOutside = this.clickOutside.bind(this);
		this.onMultiComplete = this.onMultiComplete.bind(this);
		this.removeItem = this.removeItem.bind(this);
		this.markTodoDone = this.markTodoDone.bind(this);
		this.EditCompletedItem = this.EditCompletedItem.bind(this);
		this.DeleteCompletedItem = this.DeleteCompletedItem.bind(this);
		this.updateTodo = this.updateTodo.bind(this);
		this.onCompleteItemDelete = this.onCompleteItemDelete.bind(this);


	}
	componentDidMount() {
		window.addEventListener('click', this.clickOutside);
	}



	clickOutside(e) {
		if (!document.querySelector('[data-area]').contains(e.target)) {
			this.state.items.forEach(function (obj, index) {
				if (obj.edit === true) {
					obj.edit = false;
				}
			});
			this.setState(this.state);
		}
	}

	onItemAdd(name, color) {
		this.state.items.push({
			name: name,
			color: color,
			checked: false,
			edit: false,
			id: itemId,
		});
		this.setState(this.state);
		itemId += 1;
	}


	onItemEdit(name, color, id) {
		var array = this.state.items;
		var index = this.getIndex(id, array, 'id');
		this.state.items[index].name = name;
		this.state.items[index].color = color;
		this.state.items[index].edit = false;
		this.setState(this.state);
		//console.log('new name: ' + name + ' new color: ' + color + ' id: ' + id);
	}
	getIndex(value, arr, prop) {
		for (var i = 0; i < arr.length; i++) {
			if (arr[i][prop] === value) {
				return i;
			}
		}
		return -1; //to handle the case where the value doesn't exist
	}
	onItemDelete(index) {
		this.state.items.splice(index, 1);
		this.setState(this.state);
	}

	onCheckedChecker(checked, id) {
		var array = this.state.items;
		var index = this.getIndex(id, array, 'id');
		var counter = [];

		if (this.state.items[index].edit === true) {
			this.state.items[index].edit = false;
		}
		this.state.items[index].checked = checked;
		this.setState(this.state);

		this.state.items.forEach(function (obj, index) {
			if (obj.checked === true) {
				counter.push(obj);
			}
		});
		if (counter.length > 0) {
			this.state.countChecked = true;
		} else {
			this.state.countChecked = false;
		}
		this.state.checkedNum = counter.length;
	}
	onMultiComplete() {
		var items = this.state.items;
		var keep = [];
		var completeitems = [];
		if (localStorage && localStorage.getItem('completeitems') != undefined) {
			var FinalSkudetails = localStorage.getItem('completeitems');
			FinalSkudetails = JSON.parse(FinalSkudetails);
			completeitems = FinalSkudetails;
		}


		this.state.items.forEach(function (obj, index) {
			if (obj.checked !== true) {
				keep.push(items[index]);
			}
			if (obj.checked === true) {
				items[index].done = "Unfinish";
				completeitems.push(items[index]);
			}
		});

		localStorage.setItem('completeitems', JSON.stringify(completeitems));
		//alert(JSON.stringify(completeitems))
		this.setState({
			items: keep,
			completeitems: completeitems,
			countChecked: false,
			checkedNum: 1,
		});
	}



	removeItem(itemIndex) {

		this.state.completeitems.splice(itemIndex, 1);
		this.setState(this.state);
	}
	markTodoDone(itemIndex) {
		var todo = this.state.completeitems[itemIndex];
		this.state.completeitems.splice(itemIndex, 1);
		todo.done = !todo.done;
		todo.done ? this.state.completeitems.push(todo) : this.state.completeitems.unshift(todo);
		this.setState(this.state);
	}
	onMultiDelete() {
		var items = this.state.items;
		var keep = [];
		this.state.items.forEach(function (obj, index) {
			//alert(obj.id)
			if (obj.checked !== true) {
				keep.push(items[index]);
			}
		});
		this.setState({
			items: keep,
			countChecked: false,
			checkedNum: 1,
		});
	}

	onEditCheck(flag, id) {
		//alert(JSON.stringify(this.state.items))
		var array = this.state.items;
		var index = this.getIndex(id, array, 'id');
		var counter = [];

		this.state.items[index].edit = flag;
		this.setState(this.state);


		this.state.items.forEach(function (obj, index) {
			if (obj.edit === true) {
				counter.push(obj);
			}
		});

		if (counter.length > 1) {
			this.state.items.forEach(function (obj, index) {
				obj.edit = false;
			});
			this.state.items[index].edit = true;
			this.setState(this.state);

			counter.splice(0, 1);
		}

	}
	EditCompletedItem(obj, itemsarray) {

		//$("#editbtn"). prop("value", "Save");
		//$("#editbtn"). html("Save");
		for (var i = 0; i < itemsarray.length; i++) {
			if (itemsarray[i].id == obj.id) {
				this.setState({
					editstatus: 'true',
					name: obj.name, savestatus: 'true'

				});

				$('#changetext' + i).css({
					'display': 'block',
				});
				$('#editbtn').css({
					'display': 'none', height: "40px"
				});
				$('#savebtn').css({
					'display': 'block', height: "40px"
				});
			}
		}

	}

	saveCompletedItem(obj, itemsarray) {

		for (var i = 0; i < itemsarray.length; i++) {
			if (itemsarray[i].id == obj.id) {
				itemsarray[i].name = this.state.name;
				this.setState({
					editstatus: 'false',
					name: obj.name, savestatus: 'false',
					completeitems: itemsarray

				});
				$('#changetext' + i).css({
					'display': 'none',
				});
				$('#editbtn').css({
					'display': 'block', height: "40px"
				});
				$('#savebtn').css({
					'display': 'none', height: "40px"
				});
			}
		}

	}


	onNameChange(e) {
		this.state.name = e.target.value;
		this.setState(this.state);
	}
	DeleteCompletedItem(itemIndex, obj, itemsarray) {
		var completeitems = [];
		if (localStorage && localStorage.getItem('completeitems') != undefined) {
			var FinalSkudetails = localStorage.getItem('completeitems');
			FinalSkudetails = JSON.parse(FinalSkudetails);
			completeitems = FinalSkudetails;

			for (var i = 0; i < completeitems.length; i++) {
				if (completeitems[i].id == obj.id) {
					completeitems.splice(i, 1);
				}
			}

		}
		localStorage.setItem('completeitems', JSON.stringify(completeitems));
		this.state.completeitems.splice(itemIndex, 1);
		this.setState(this.state);
	}


	updateTodo(newTodo) {
		this.setState(state => ({
			completeitems: state.completeitems.map(todo => todo.id === newTodo.id ? newTodo : todo)
		}));
	}

	onCompleteItemDelete(index) {
		this.state.completeitems.splice(index, 1);
		this.setState(this.state);
	}
	render() {


		return (
			<div className="App">
				<div className="container">
					<Header1 checkedItemsFlag={this.state.countChecked} number={this.state.checkedNum} handleCompleteItems={this.onMultiComplete} />
					<Header checkedItemsFlag={this.state.countChecked} number={this.state.checkedNum} handleDeleteItems={this.onMultiDelete} />
					<ul className="list" data-area>
						{this.state.items.length == 0 ? <h3 className="TextBold">No ToDo List Available .Please add todo's</h3> : <h3 className="TextBold">Available ToDo List</h3>}
						{this.state.items.map(function (item, index) {
							return (
								<Item
									name={item.name}
									color={item.color}
									checked={item.checked}
									edit={item.edit}
									key={item.id}
									id={item.id}
									onCheckedCheck={this.onCheckedChecker}
									onPassDelete={function () { this.onItemDelete(index) }.bind(this)}
									editFlag={this.onEditCheck}
									editColorList={this.props.colors}
									onEdit={this.onItemEdit}
								/>
							);
						}.bind(this))}
					</ul>
					<AddItemForm onAdd={this.onItemAdd} colorList={this.props.colors} />
					{this.state.completeitems.length > 0 ? <div>
						<h3 className="TextBold">Completed ToDo List</h3>
						<ul className="list" data-area>

							{this.state.completeitems.map(todo =>
								<TodoItem key={todo.id} todo={todo} updateTodo={this.updateTodo} onCompleteItemDelete={this.onCompleteItemDelete} />
								)}
							
						</ul></div> : ""}
				</div>
			</div>
		);
	}
}
App.propTypes = {
	//	initialItems: PropTypes.array.isRequired,
	//colors: PropTypes.array.isRequired,
};
export default App;




class TodoItem extends Component {




	//const TodoItem = React.createClass({
	handleChange(e) { this.sendDelta({ name: e.target.value }); }
	handleClick() { this.sendDelta({ done: !this.props.todo.done }); }
	DeleteCompletedItem() { this.deleteDelta({ index: this.props.todo.id }); }
	sendDelta(delta) {
		let newTodo = Object.assign({}, this.props.todo, delta);
		this.props.updateTodo(newTodo);
	}

	deleteDelta(delta) {
		let newTodo = Object.assign({}, this.props.todo, delta);
		this.props.onCompleteItemDelete(newTodo);
	}

	render() {
		const { todo } = this.props;
		return (



			<table style={{ "width": "100%", marginTop: "0%" }}>
				<tbody id="myTable">
					<tr>
						{/* <td>
						<input value={todo.name} className="done" disabled={todo.done} onChange={(e) => this.handleChange(e)} />
							<button style={{ width: "20%", backgroundColor: "blue",borderRadius:"5px",borderColor:"transparent",height:"30px",color:"wite" }} onClick={(e) => this.handleClick(e)}>
								{todo.done ? "Edit" : "Save"}
							</button></td> */}

							<td>
							<input style={{width:"80%",height:"40px"}} className="form__inputText--lg form__inputText--addItem" type="text" name="name" value={todo.name} className="done" disabled={todo.done} onChange={(e) => this.handleChange(e)} />
							<button style={{ width: "20%", backgroundColor: "blue",borderRadius:"5px",borderColor:"transparent",height:"40px",color:"white" }} onClick={(e) => this.handleClick(e)}>
								{todo.done ? "Edit" : "Save"}
							</button>
							</td>
						<td style={{ textAlign: "center", fontSize: "16px", height: "40px", backgroundColor: "red" }}>
							<div><button className="cartProceedbtn" style={{ width: "20%", backgroundColor: "red" }} fluid onClick={(e) => this.DeleteCompletedItem(e)} >
								Delete &nbsp;
                     						   </button></div>
						</td>
					</tr>
				</tbody>
			</table>
		);
	}
}
TodoItem.propTypes = {
	index: PropTypes.number,
	removeItem: PropTypes.func.isRequired,
	updateTodo: PropTypes.func.isRequired,
	onCompleteItemDelete: PropTypes.func.isRequired,
};



class TodoListItem extends React.Component {
	constructor(props) {
		super(props);
		this.onClickClose = this.onClickClose.bind(this);
		this.onClickDone = this.onClickDone.bind(this);
	}
	onClickClose() {
		var index = parseInt(this.props.index);
		//  alert(this.props.index)
		// this.props.handleDeleteItems();
		this.props.removeItem(index);
	}
	onClickDone() {

		var index = parseInt(this.props.index);
		this.props.markTodoDone(index);
	}
	render() {
		var todoClass = this.props.item.done ?
			"done" : "undone";
		return (
			<li className="list-group-item ">




				<div className={todoClass}>
					<span className="glyphicon glyphicon-ok icon" aria-hidden="true" onClick={this.onClickDone}></span>
					{this.props.item.name}
					<button type="button" className="close" onClick={this.onClickClose}>Delete &times;</button>
				</div>
			</li>
		);
	}
}
TodoListItem.propTypes = {
	index: PropTypes.number,
	removeItem: PropTypes.func.isRequired,
	editFlag: PropTypes.func.isRequired,
};


class Header extends Component {

	constructor(props) {
		super(props)
		this.state = {
			title: 'React Todo List ',
		}

	}

	handleClick() {
		//	e.preventDefault();
		this.props.handleDeleteItems();
	}
	render() {
		var showLinkClass = this.props.checkedItemsFlag ? 'is--visible' : '';
		var number = this.props.number;
		return (
			<header>
				<h1 className="clearfix">
					{this.props.title}
					<a
						className={`float--right text--xs spacer--top--xs text--reg is--hidden ${showLinkClass}`}
						href="#"
						onClick={(event) => this.handleClick(event)}>
						Delete selected Items ({number})
					</a>
				</h1>
			</header>
		);
	}


}
Header.propTypes = {
	title: PropTypes.string,
	checkedItemsFlag: PropTypes.bool.isRequired,
	handleDeleteItems: PropTypes.func.isRequired,
	number: PropTypes.number,
};






class Header1 extends Component {

	constructor(props) {
		super(props)
		this.state = {
			title: 'React Todo List ',
		}

	}

	handleClick() {
		//	e.preventDefault();
		this.props.handleCompleteItems();
	}
	render() {
		var showLinkClass = this.props.checkedItemsFlag ? 'is--visible' : '';
		var number = this.props.number;
		return (
			<header>
				<h1 className="clearfix">

					<a
						className={`float--right text--xs spacer--top--xs text--reg is--hidden ${showLinkClass}`}
						href="#"
						onClick={(event) => this.handleClick(event)}>
						Complete selected Items ({number})
					</a>
				</h1>
			</header>
		);
	}


}
Header1.propTypes = {
	title: PropTypes.string,
	checkedItemsFlag: PropTypes.bool.isRequired,
	//	handleDeleteItems: PropTypes.func.isRequired,
	handleCompleteItems: PropTypes.func.isRequired,
	number: PropTypes.number,
};



class Item extends Component {

	constructor(props) {
		super(props)
		this.state = {
			clicked: false,
			checked: false,
			editSwitch: false,
		}
		this.handleClick = this.handleClick.bind(this);
		this.handleChange = this.handleChange.bind(this);
		this.onEditSwitch = this.onEditSwitch.bind(this);

	}



	handleClick() {
		this.state.clicked = this.state.clicked ? false : true;
		this.setState(this.state);
	}

	handleChange(e) {
		this.state.checked = e.target.checked;
		this.props.onCheckedCheck(this.state.checked, this.props.id);
		this.setState(this.state);
	}

	onEditSwitch() {
		this.state.editSwitch = true;
		this.setState(this.state);
		this.props.editFlag(this.state.editSwitch, this.props.id);
	}












	render() {
		var colorClass = this.props.color ? this.props.color : '';
		var checkedClass = this.state.checked ? 'disabled' : '';

		return (
			<li className={`list__item ${colorClass} ${checkedClass}`} data-id={this.props.id}>
				<div className="list__checkbox">
					<input type="checkbox" onChange={this.handleChange} />
				</div>

				<div className="list__name">
					<p className="list__text" onClick={this.onEditSwitch}>{this.props.name}</p>
					<EditItemForm
						editMode={this.props.edit}
						val={this.props.name}
						color={this.props.color}
						colorList={this.props.editColorList}
						notifyEdits={this.props.onEdit}
						id={this.props.id}
					/>
				</div>
			</li>
		);
	}

}
Item.propTypes = {
	name: PropTypes.string.isRequired,
	color: PropTypes.string,
	checked: PropTypes.bool.isRequired,
	edit: PropTypes.bool.isRequired,
	id: PropTypes.number.isRequired,
	onPassDelete: PropTypes.func.isRequired,
	onCheckedCheck: PropTypes.func.isRequired,
	editFlag: PropTypes.func.isRequired,
	editColorList: PropTypes.array.isRequired,

	//product: productPropType.isRequired,
};



class AddItemForm extends Component {

	constructor(props) {
		super(props)
		this.state = {
			name: '',
			color: 'red',
		}
		this.onSubmit = this.onSubmit.bind(this);
	}


	onSubmit(e) {
		e.preventDefault();

		var name = this.state.name;
		var color = this.state.color;

		if (name != '') {
			this.props.onAdd(name, color);
			this.setState({
				name: '',
				color: 'white'
			});
		}
	}

	onNameChange(e) {
		this.state.name = e.target.value;
		this.setState(this.state);
	}

	onColorChange(e) {
		this.state.color = e.target.getAttribute('data-color');
		this.setState(this.state);
	}
	render() {


		return (
			<form onSubmit={this.onSubmit}>
				<input className="form__inputText--lg form__inputText--addItem" type="text" name="name" value={this.state.name} onChange={(event) => this.onNameChange(event)} placeholder="Add New Item" />

				<input className="form__inputSubmit--inside" type="submit" value="Add" />
			</form>
		);
	}
}

AddItemForm.propTypes = {
	onAdd: PropTypes.func.isRequired,
	colorList: PropTypes.array,
};


class EditItemForm extends Component {

	constructor(props) {
		super(props)
		this.state = {
			newName: this.props.val,
			newColor: this.props.color,
		}
	}

	componentWillReceiveProps(nextProps) {
		if (nextProps.editMode === false) {
			this.setState({
				newName: nextProps.val,
				newColor: nextProps.color,
			});
		}
	}



	onValueChange(e) {
		this.state.newName = e.target.value;
		this.setState(this.state);
	}
	onColorChange(e) {
		this.state.newColor = e.target.getAttribute('data-color');
		this.setState(this.state);
	}
	onSubmit(e) {
		e.preventDefault();

		var name = this.state.newName;
		var color = this.state.newColor;
		var id = this.props.id;

		if (name != '') {
			this.props.notifyEdits(name, color, id);
		}
	}



	render() {
		var editClass = this.props.editMode ? 'is--show' : '';



		return (
			<form className={`list__form ${editClass}`} onSubmit={(event) => this.onSubmit(event)}>
				<input
					className="form__inputText--lg form__inputText--addItem"
					type="text"
					ref="editInput"
					onChange={(event) => this.onValueChange(event)}
					value={this.state.newName}
				/>

				<input className="form__inputSubmit--inside" type="submit" value="Save" />
			</form>
		);
	}
}

EditItemForm.propTypes = {
	editMode: PropTypes.bool.isRequired,
	val: PropTypes.string.isRequired,
	colorList: PropTypes.array.isRequired,
	color: PropTypes.string,
};